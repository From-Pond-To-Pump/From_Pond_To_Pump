import { useReveal } from './hooks/useReveal';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Methodology from './components/Methodology';
import Journal from './components/Journal';
import Gallery from './components/Gallery';
import Researcher from './components/Researcher';
import Footer from './components/Footer';

// =============================================
// FROM POND TO PUMP — MAIN APPLICATION
// =============================================
//
// HOW TO EDIT THIS WEBSITE:
// ─────────────────────────
// Each section is in its own file under src/components/.
// Open any component file and look for comments like:
//
//   // EDIT: ...
//
// These mark every place where you should plug in
// your own text, images, links, and data.
//
// COMPONENT FILES:
// ── src/components/Navbar.tsx      → Navigation links
// ── src/components/Hero.tsx        → Title, subtitle, CTA
// ── src/components/About.tsx       → Research mission
// ── src/components/Methodology.tsx → 6-panel prototype steps
// ── src/components/Journal.tsx     → Downloadable resources
// ── src/components/Gallery.tsx     → Photo grid
// ── src/components/Researcher.tsx  → Bio & contact info
// ── src/components/Footer.tsx      → Footer links & copyright
// =============================================

export default function App() {
  // Initialize scroll-reveal animations
  useReveal();

  return (
    <div className="min-h-screen bg-white text-slate-900 antialiased">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Methodology />
        <Journal />
        <Gallery />
        <Researcher />
      </main>
      <Footer />
    </div>
  );
}
