import { ArrowDown, Leaf, Beaker, Waves } from 'lucide-react';

/* =============================================
   HERO SECTION
   ── Edit the title, subtitle, and CTA below
   ── Replace the background gradient/image by
      swapping the inline style or adding your
      own <img> / background-image URL
   ============================================= */

export default function Hero() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center overflow-hidden">
      {/* ── BACKGROUND IMAGE PLACEHOLDER ──
          Replace the gradient below with your own image:
          style={{ backgroundImage: "url('/your-image.jpg')" }}
      */}
      <div className="absolute inset-0 bg-gradient-to-br from-forest-950 via-forest-900 to-water-900" />

      {/* Decorative overlay patterns */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full"
          style={{
            backgroundImage: `radial-gradient(circle at 20% 50%, rgba(34,197,94,0.3) 0%, transparent 50%),
                              radial-gradient(circle at 80% 20%, rgba(6,182,212,0.3) 0%, transparent 50%),
                              radial-gradient(circle at 60% 80%, rgba(34,197,94,0.2) 0%, transparent 50%)`
          }}
        />
      </div>

      {/* Animated floating elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-[10%] animate-float opacity-20">
          <Leaf className="w-16 h-16 text-forest-400" />
        </div>
        <div className="absolute top-1/3 right-[15%] animate-float opacity-15" style={{ animationDelay: '2s' }}>
          <Beaker className="w-12 h-12 text-water-400" />
        </div>
        <div className="absolute bottom-1/4 left-[20%] animate-float opacity-15" style={{ animationDelay: '4s' }}>
          <Waves className="w-14 h-14 text-water-300" />
        </div>
      </div>

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                            linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: '60px 60px'
        }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-32">
        <div className="max-w-4xl">
          {/* ── BADGE / TAGLINE ── */}
          <div className="animate-fade-in-up inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full text-white/90 text-sm font-medium mb-8">
            <span className="w-2 h-2 bg-forest-400 rounded-full animate-pulse" />
            {/* EDIT: Change the tagline here */}
            Open-Source Environmental Research
          </div>

          {/* ── MAIN TITLE ── */}
          <h1 className="animate-fade-in-up font-serif text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-bold text-white leading-[1.1] tracking-tight mb-6"
            style={{ animationDelay: '0.15s' }}
          >
            {/* EDIT: Your project title */}
            From Pond
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-forest-300 to-water-300">
              to Pump
            </span>
          </h1>

          {/* ── SUBTITLE ── */}
          <p className="animate-fade-in-up text-lg sm:text-xl lg:text-2xl text-white/70 max-w-2xl leading-relaxed mb-10 font-light"
            style={{ animationDelay: '0.3s' }}
          >
            {/* EDIT: Your project subtitle / description */}
            Harvesting nitrogen-stressed microalgae from eutrophic water bodies to produce low-cost, zero-waste biofuels — turning ecological crisis into clean energy.
          </p>

          {/* ── CALL TO ACTION BUTTONS ── */}
          <div className="animate-fade-in-up flex flex-col sm:flex-row gap-4" style={{ animationDelay: '0.45s' }}>
            <a
              href="#journal"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-forest-500 hover:bg-forest-400 text-white font-semibold rounded-xl transition-all duration-300 shadow-xl shadow-forest-900/30 hover:shadow-forest-500/30 hover:-translate-y-0.5"
            >
              {/* EDIT: Primary CTA text */}
              Read the Journal
            </a>
            <a
              href="#about"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white font-semibold rounded-xl border border-white/20 transition-all duration-300 hover:-translate-y-0.5"
            >
              {/* EDIT: Secondary CTA text */}
              Explore the Research
            </a>
          </div>

          {/* ── QUICK STATS ── */}
          <div className="animate-fade-in-up mt-16 grid grid-cols-3 gap-6 max-w-lg" style={{ animationDelay: '0.6s' }}>
            {/* EDIT: Update these statistics */}
            {[
              { value: '6', label: 'Panel Sections' },
              { value: '100%', label: 'Zero Waste' },
              { value: 'Open', label: 'Source Data' },
            ].map((stat, i) => (
              <div key={i} className="text-center sm:text-left">
                <div className="text-2xl sm:text-3xl font-bold text-white">{stat.value}</div>
                <div className="text-xs sm:text-sm text-white/50 font-medium mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <a href="#about" className="flex flex-col items-center gap-2 text-white/40 hover:text-white/70 transition-colors">
          <span className="text-xs font-medium tracking-widest uppercase">Scroll</span>
          <ArrowDown className="w-4 h-4" />
        </a>
      </div>
    </section>
  );
}
