import { Camera, ZoomIn, X } from 'lucide-react';
import { useState } from 'react';

/* =============================================
   GALLERY SECTION
   ── Edit the GALLERY_ITEMS array below.
   ── Replace each item's placeholder with your
      real image URL and caption.
   ── To add an image, just add a new object to
      the array with { src, alt, caption, span? }
   ============================================= */

/* EDIT: Replace with your actual images and captions */
const GALLERY_ITEMS = [
  {
    src: '', // EDIT: e.g., "/images/gallery/field-survey-1.jpg"
    alt: 'Field survey at local pond',
    caption: 'Field survey and water sampling at a eutrophic pond site',
    span: 'col-span-2 row-span-2', // large feature image
    gradient: 'from-forest-600 to-forest-800',
  },
  {
    src: '',
    alt: 'Water quality testing',
    caption: 'On-site water quality and nutrient concentration testing',
    span: '',
    gradient: 'from-water-500 to-water-700',
  },
  {
    src: '',
    alt: 'Algae cultivation in lab',
    caption: 'Controlled microalgae cultivation under nitrogen stress',
    span: '',
    gradient: 'from-forest-500 to-water-600',
  },
  {
    src: '',
    alt: 'Community awareness program',
    caption: 'Community outreach and environmental awareness presentation',
    span: 'col-span-2',
    gradient: 'from-water-600 to-forest-600',
  },
  {
    src: '',
    alt: 'Algal biomass harvesting',
    caption: 'Harvesting lipid-rich microalgal biomass for processing',
    span: '',
    gradient: 'from-forest-700 to-forest-900',
  },
  {
    src: '',
    alt: 'Lipid extraction process',
    caption: 'Lipid extraction and transesterification setup',
    span: '',
    gradient: 'from-water-700 to-water-900',
  },
  {
    src: '',
    alt: 'School awareness campaign',
    caption: 'Student awareness campaign at a local school',
    span: '',
    gradient: 'from-forest-600 to-water-700',
  },
  {
    src: '',
    alt: 'Biofuel product sample',
    caption: 'Final biodiesel sample produced from algal lipids',
    span: '',
    gradient: 'from-amber-500 to-forest-600',
  },
];

export default function Gallery() {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  return (
    <section id="gallery" className="relative py-24 lg:py-32 bg-slate-50 overflow-hidden">
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 lg:mb-20">
          <span className="reveal inline-block px-4 py-1.5 bg-water-50 text-water-700 text-sm font-semibold rounded-full border border-water-100 mb-6">
            {/* EDIT: Section label */}
            Visual Documentation
          </span>
          <h2 className="reveal reveal-delay-1 font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 leading-tight mb-6">
            {/* EDIT: Section heading */}
            Project{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-forest-600 to-water-600">
              Gallery
            </span>
          </h2>
          <p className="reveal reveal-delay-2 text-lg text-slate-500 leading-relaxed">
            {/* EDIT: Section description */}
            Photos from field surveys, laboratory work, prototype development,
            and community awareness programs.
          </p>
        </div>

        {/* Photo Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 auto-rows-[200px] md:auto-rows-[220px]">
          {GALLERY_ITEMS.map((item, i) => (
            <div
              key={i}
              className={`reveal reveal-delay-${(i % 4) + 1} group relative rounded-2xl overflow-hidden cursor-pointer ${item.span}`}
              onClick={() => setLightboxIndex(i)}
            >
              {/* ── IMAGE PLACEHOLDER ──
                  When you have real images, this will show them.
                  Otherwise it shows a styled placeholder.
              */}
              {item.src ? (
                <img
                  src={item.src}
                  alt={item.alt}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              ) : (
                <div className={`w-full h-full bg-gradient-to-br ${item.gradient} flex items-center justify-center`}>
                  <div className="text-center text-white/80 p-4">
                    <Camera className="w-8 h-8 mx-auto mb-2 opacity-60" />
                    <p className="text-xs font-medium opacity-70 leading-snug">{item.alt}</p>
                  </div>
                </div>
              )}

              {/* Hover overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                <div className="flex items-end justify-between w-full">
                  <p className="text-white text-sm font-medium leading-snug max-w-[80%]">
                    {item.caption}
                  </p>
                  <ZoomIn className="w-5 h-5 text-white/70 flex-shrink-0" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightboxIndex !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightboxIndex(null)}
        >
          <button
            onClick={() => setLightboxIndex(null)}
            className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <div className="max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
            {GALLERY_ITEMS[lightboxIndex].src ? (
              <img
                src={GALLERY_ITEMS[lightboxIndex].src}
                alt={GALLERY_ITEMS[lightboxIndex].alt}
                className="w-full rounded-xl"
              />
            ) : (
              <div className={`w-full aspect-video rounded-xl bg-gradient-to-br ${GALLERY_ITEMS[lightboxIndex].gradient} flex items-center justify-center`}>
                <div className="text-center text-white p-8">
                  <Camera className="w-16 h-16 mx-auto mb-4 opacity-60" />
                  <p className="text-lg font-medium opacity-80">{GALLERY_ITEMS[lightboxIndex].alt}</p>
                  <p className="text-sm mt-2 opacity-50">Replace with your image file</p>
                </div>
              </div>
            )}
            <p className="text-white/80 text-center mt-4 text-sm">
              {GALLERY_ITEMS[lightboxIndex].caption}
            </p>
          </div>
        </div>
      )}
    </section>
  );
}
