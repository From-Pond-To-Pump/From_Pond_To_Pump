import { FileText, BarChart3, Download, ExternalLink, Database, BookOpen } from 'lucide-react';

/* =============================================
   OPEN-SOURCE JOURNAL / RESOURCES SECTION
   ── Edit the RESOURCES array below to add your
      downloadable PDFs, survey data, and reports.
   ── Set each item's `href` to the file URL or
      path (e.g., "/downloads/report.pdf")
   ============================================= */

/* EDIT: Add your own resources here */
const RESOURCES = [
  {
    icon: FileText,
    category: 'Research Paper',
    title: 'Full Research Report: From Pond to Pump',
    description:
      'Comprehensive documentation of methodology, findings, lipid yield analysis, and biofuel production outcomes from field and lab work.',
    href: '#', // EDIT: Replace with your PDF link, e.g., "/files/full-report.pdf"
    fileSize: 'PDF • 2.4 MB',
    accent: 'forest' as const,
  },
  {
    icon: BarChart3,
    category: 'Survey Data',
    title: 'Water Quality & Eutrophication Survey',
    description:
      'Raw and processed survey data from local water bodies including nitrogen levels, phosphorus concentrations, dissolved oxygen, and algal biomass measurements.',
    href: '#', // EDIT: Replace with your data file link
    fileSize: 'CSV / PDF • 1.1 MB',
    accent: 'water' as const,
  },
  {
    icon: BookOpen,
    category: 'Journal Entry',
    title: 'Field Journal: Awareness & Community Outreach',
    description:
      'Documentation of public awareness campaigns, community surveys, school presentations, and stakeholder feedback on the project\u0027s social impact.',
    href: '#', // EDIT: Replace with your PDF link
    fileSize: 'PDF • 980 KB',
    accent: 'forest' as const,
  },
  {
    icon: Database,
    category: 'Raw Data',
    title: 'Lipid Extraction & Yield Analysis Dataset',
    description:
      'Complete lipid extraction data across multiple algal species and stress conditions. Includes transesterification efficiency metrics and FAME composition tables.',
    href: '#', // EDIT: Replace with your data file link
    fileSize: 'XLSX / PDF • 540 KB',
    accent: 'water' as const,
  },
  {
    icon: FileText,
    category: 'Technical Brief',
    title: 'Prototype Assembly & Replication Guide',
    description:
      'Step-by-step technical guide for replicating the 6-Section Algal Panel Prototype, including materials list, estimated costs, and troubleshooting notes.',
    href: '#', // EDIT: Replace with your PDF link
    fileSize: 'PDF • 1.8 MB',
    accent: 'forest' as const,
  },
  {
    icon: BarChart3,
    category: 'Presentation',
    title: 'Project Presentation Slides',
    description:
      'The slide deck used for academic presentations and science fairs. Summarizes the research problem, methodology, results, and future scope.',
    href: '#', // EDIT: Replace with your file link
    fileSize: 'PDF • 3.2 MB',
    accent: 'water' as const,
  },
];

const accentMap = {
  forest: {
    badge: 'bg-forest-50 text-forest-700 border-forest-200',
    iconBg: 'bg-forest-100',
    iconColor: 'text-forest-600',
    button: 'bg-forest-600 hover:bg-forest-700 shadow-forest-600/25',
  },
  water: {
    badge: 'bg-water-50 text-water-700 border-water-200',
    iconBg: 'bg-water-100',
    iconColor: 'text-water-600',
    button: 'bg-water-600 hover:bg-water-700 shadow-water-600/25',
  },
};

export default function Journal() {
  return (
    <section id="journal" className="relative py-24 lg:py-32 bg-white overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-slate-200 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 lg:mb-20">
          <span className="reveal inline-block px-4 py-1.5 bg-forest-50 text-forest-700 text-sm font-semibold rounded-full border border-forest-100 mb-6">
            {/* EDIT: Section label */}
            Open-Source Resources
          </span>
          <h2 className="reveal reveal-delay-1 font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 leading-tight mb-6">
            {/* EDIT: Section heading */}
            Journal &{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-forest-600 to-water-600">
              Research Data
            </span>
          </h2>
          <p className="reveal reveal-delay-2 text-lg text-slate-500 leading-relaxed">
            {/* EDIT: Section description */}
            All data, reports, and publications from this project are freely available.
            Download, replicate, and build upon our work — knowledge should be open.
          </p>
        </div>

        {/* Resources Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {RESOURCES.map((resource, i) => {
            const colors = accentMap[resource.accent];
            const Icon = resource.icon;
            return (
              <div
                key={i}
                className={`reveal reveal-delay-${(i % 3) + 1} group relative bg-white rounded-2xl border-2 border-slate-100 hover:border-slate-200 p-6 transition-all duration-500 hover:shadow-xl hover:shadow-slate-900/5 hover:-translate-y-1 flex flex-col`}
              >
                {/* Top row: icon + category */}
                <div className="flex items-start justify-between mb-5">
                  <div className={`p-3 rounded-xl ${colors.iconBg}`}>
                    <Icon className={`w-6 h-6 ${colors.iconColor}`} />
                  </div>
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border ${colors.badge}`}>
                    {resource.category}
                  </span>
                </div>

                {/* Title & description */}
                <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-forest-700 transition-colors">
                  {/* EDIT: Resource title */}
                  {resource.title}
                </h3>
                <p className="text-sm text-slate-500 leading-relaxed mb-6 flex-grow">
                  {/* EDIT: Resource description */}
                  {resource.description}
                </p>

                {/* Download button & file size */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                  <span className="text-xs text-slate-400 font-medium">
                    {resource.fileSize}
                  </span>
                  {/* EDIT: Update the href to your actual file URL */}
                  <a
                    href={resource.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`inline-flex items-center gap-2 px-4 py-2 text-white text-sm font-semibold rounded-lg transition-all duration-300 shadow-md ${colors.button} hover:-translate-y-0.5`}
                  >
                    <Download className="w-4 h-4" />
                    Download
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* External links callout */}
        <div className="reveal mt-12 text-center">
          <p className="text-slate-400 text-sm">
            {/* EDIT: Add any external link or note */}
            Need something else?{' '}
            <a href="#researcher" className="text-forest-600 hover:text-forest-700 font-semibold inline-flex items-center gap-1">
              Contact the researcher <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}
