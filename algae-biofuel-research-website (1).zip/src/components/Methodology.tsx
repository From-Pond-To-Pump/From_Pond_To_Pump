import { FlaskConical, SunMedium, Droplet, Filter, Beaker, Fuel } from 'lucide-react';

/* =============================================
   PROTOTYPE & METHODOLOGY SECTION
   ── This section is designed for the
      "6-Section Algal Panel Prototype"
   ── Edit each step's title, description,
      and replace placeholders with real images
   ============================================= */

/* EDIT: Update each of the 6 prototype panel steps */
const PANEL_STEPS = [
  {
    step: 1,
    icon: Droplet,
    title: 'Collection & Sampling',
    description:
      'Water samples rich in microalgae are collected from eutrophic ponds and local water bodies showing signs of nutrient overloading and algal bloom formation.',
    imageAlt: 'Field collection from eutrophic pond',
    color: 'from-water-500 to-water-600',
    lightColor: 'bg-water-50 text-water-700 border-water-200',
  },
  {
    step: 2,
    icon: FlaskConical,
    title: 'Isolation & Cultivation',
    description:
      'Target microalgae species are isolated and cultivated under controlled conditions. Nitrogen stress is applied to trigger lipid accumulation — a key step for biofuel viability.',
    imageAlt: 'Lab cultivation setup',
    color: 'from-forest-500 to-forest-600',
    lightColor: 'bg-forest-50 text-forest-700 border-forest-200',
  },
  {
    step: 3,
    icon: SunMedium,
    title: 'Nitrogen Stress Induction',
    description:
      'Cultures are systematically starved of nitrogen, redirecting cellular metabolism toward lipid biosynthesis. This increases oil content from ~15% to over 40% of dry cell weight.',
    imageAlt: 'Nitrogen stress cultures under light',
    color: 'from-amber-500 to-orange-500',
    lightColor: 'bg-amber-50 text-amber-700 border-amber-200',
  },
  {
    step: 4,
    icon: Filter,
    title: 'Harvesting & Dewatering',
    description:
      'Mature, lipid-rich biomass is harvested using low-energy flocculation and filtration methods designed for cost-effectiveness and scalability in resource-limited settings.',
    imageAlt: 'Harvesting and filtration process',
    color: 'from-water-600 to-forest-600',
    lightColor: 'bg-teal-50 text-teal-700 border-teal-200',
  },
  {
    step: 5,
    icon: Beaker,
    title: 'Lipid Extraction',
    description:
      'Algal lipids are extracted using a modified Bligh-Dyer method or mechanical pressing. The remaining biomass is preserved for use as organic fertilizer — ensuring zero waste.',
    imageAlt: 'Lipid extraction in lab',
    color: 'from-forest-600 to-forest-700',
    lightColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  },
  {
    step: 6,
    icon: Fuel,
    title: 'Transesterification & Biofuel',
    description:
      'Extracted lipids undergo transesterification with methanol and a catalyst to produce biodiesel (FAMEs). The glycerol byproduct is collected for industrial reuse.',
    imageAlt: 'Final biofuel product',
    color: 'from-forest-700 to-water-800',
    lightColor: 'bg-sky-50 text-sky-700 border-sky-200',
  },
];

export default function Methodology() {
  return (
    <section id="methodology" className="relative py-24 lg:py-32 bg-slate-50 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: `radial-gradient(circle at 30% 20%, rgba(22,163,74,0.08) 0%, transparent 50%),
                            radial-gradient(circle at 70% 80%, rgba(6,182,212,0.08) 0%, transparent 50%)`
        }}
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 lg:mb-20">
          <span className="reveal inline-block px-4 py-1.5 bg-water-50 text-water-700 text-sm font-semibold rounded-full border border-water-100 mb-6">
            {/* EDIT: Section label */}
            Prototype & Process
          </span>
          <h2 className="reveal reveal-delay-1 font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 leading-tight mb-6">
            {/* EDIT: Section heading */}
            The 6-Section{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-forest-600 to-water-600">
              Algal Panel Prototype
            </span>
          </h2>
          <p className="reveal reveal-delay-2 text-lg text-slate-500 leading-relaxed">
            {/* EDIT: Section description */}
            A step-by-step, modular approach to converting eutrophic algae into viable biofuel.
            Each panel represents a critical phase designed for replicability and low-cost implementation.
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid gap-8 lg:gap-10">
          {PANEL_STEPS.map((panel, i) => {
            const Icon = panel.icon;
            const isEven = i % 2 === 1;
            return (
              <div
                key={panel.step}
                className={`reveal reveal-delay-${(i % 3) + 1} group`}
              >
                <div className={`flex flex-col ${isEven ? 'lg:flex-row-reverse' : 'lg:flex-row'} gap-6 lg:gap-10 bg-white rounded-2xl border border-slate-200 hover:border-slate-300 p-6 lg:p-8 transition-all duration-500 hover:shadow-xl hover:shadow-slate-900/5`}>
                  {/* ── IMAGE PLACEHOLDER ──
                      Replace the placeholder below with your actual step photo:
                      <img src="/images/step-{n}.jpg" alt="..." className="w-full h-full object-cover" />
                  */}
                  <div className="lg:w-2/5 flex-shrink-0">
                    <div className={`relative aspect-[4/3] rounded-xl bg-gradient-to-br ${panel.color} overflow-hidden flex items-center justify-center`}>
                      <div className="absolute inset-0 animate-shimmer" />
                      <div className="text-center text-white/90 p-6 relative z-10">
                        <Icon className="w-12 h-12 mx-auto mb-3 opacity-80" />
                        <p className="text-sm font-medium opacity-70">
                          {/* EDIT: Replace with <img> tag for real photo */}
                          Step {panel.step} Photo Placeholder
                        </p>
                        <p className="text-xs mt-1 opacity-50">{panel.imageAlt}</p>
                      </div>
                    </div>
                  </div>

                  {/* Text Content */}
                  <div className="lg:w-3/5 flex flex-col justify-center">
                    <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold w-fit mb-4 border ${panel.lightColor}`}>
                      <span>PANEL {panel.step} OF 6</span>
                    </div>
                    <h3 className="text-xl lg:text-2xl font-bold text-slate-900 mb-3">
                      {/* EDIT: Step title */}
                      {panel.title}
                    </h3>
                    <p className="text-slate-500 leading-relaxed">
                      {/* EDIT: Step description */}
                      {panel.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
