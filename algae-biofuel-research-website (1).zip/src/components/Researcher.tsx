import { Mail, MapPin, GraduationCap, ExternalLink, Github, Linkedin } from 'lucide-react';

/* =============================================
   ABOUT THE RESEARCHER SECTION
   ── Edit the researcher details below
   ── Replace the headshot placeholder with a
      real image URL
   ── Update social/contact links
   ============================================= */

/* EDIT: Your researcher information */
const RESEARCHER = {
  name: 'Your Name Here',
  title: 'Student Researcher',
  institution: 'Your School / Institution Name',
  location: 'City, State, Country',
  headshotUrl: '', // EDIT: e.g., "/images/headshot.jpg"
  bio: `A passionate student researcher focused on finding practical, science-driven solutions to pressing environmental challenges. The "From Pond to Pump" project emerged from a deep concern about local water pollution and a belief that sustainable energy solutions can be both affordable and impactful. This research combines environmental science, biotechnology, and community engagement to create a replicable model for algae-based biofuel production.`,
  // EDIT: Add a secondary bio paragraph or leave empty
  bioExtended: `Beyond this project, interests include aquatic ecology, renewable energy policy, and open-source science. Committed to making research accessible and actionable for communities everywhere.`,
  // EDIT: Your social and contact links (set to '' to hide)
  email: 'researcher@example.com',
  github: 'https://github.com/yourusername',
  linkedin: 'https://linkedin.com/in/yourusername',
  website: '', // EDIT: personal website URL, leave empty to hide
};

export default function Researcher() {
  return (
    <section id="researcher" className="relative py-24 lg:py-32 bg-white overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-slate-200 to-transparent" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-forest-50 rounded-full blur-3xl opacity-40 translate-x-1/3 translate-y-1/3" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 lg:mb-20">
          <span className="reveal inline-block px-4 py-1.5 bg-forest-50 text-forest-700 text-sm font-semibold rounded-full border border-forest-100 mb-6">
            {/* EDIT: Section label */}
            The Researcher
          </span>
          <h2 className="reveal reveal-delay-1 font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 leading-tight">
            {/* EDIT: Section heading */}
            About the{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-forest-600 to-water-600">
              Researcher
            </span>
          </h2>
        </div>

        {/* Profile Card */}
        <div className="reveal max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl border-2 border-slate-100 hover:border-slate-200 shadow-xl shadow-slate-900/5 overflow-hidden transition-all duration-500">
            <div className="flex flex-col md:flex-row">
              {/* ── HEADSHOT / PHOTO ──
                  Replace the placeholder with your photo
              */}
              <div className="md:w-2/5 flex-shrink-0">
                {RESEARCHER.headshotUrl ? (
                  <img
                    src={RESEARCHER.headshotUrl}
                    alt={`${RESEARCHER.name} headshot`}
                    className="w-full h-full object-cover min-h-[300px]"
                  />
                ) : (
                  <div className="w-full h-full min-h-[300px] bg-gradient-to-br from-forest-600 via-forest-700 to-water-700 flex items-center justify-center">
                    <div className="text-center text-white p-8">
                      <div className="w-24 h-24 mx-auto rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mb-4">
                        <GraduationCap className="w-10 h-10 text-white/80" />
                      </div>
                      <p className="text-sm font-medium opacity-70">
                        {/* EDIT: Replace with your headshot */}
                        Headshot Placeholder
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Bio Content */}
              <div className="md:w-3/5 p-8 lg:p-10 flex flex-col justify-center">
                <h3 className="font-serif text-2xl lg:text-3xl font-bold text-slate-900 mb-1">
                  {/* EDIT: Researcher name */}
                  {RESEARCHER.name}
                </h3>
                <p className="text-forest-600 font-semibold mb-1">
                  {/* EDIT: Title/role */}
                  {RESEARCHER.title}
                </p>
                <div className="flex items-center gap-4 text-sm text-slate-400 mb-6">
                  <span className="flex items-center gap-1">
                    <GraduationCap className="w-4 h-4" />
                    {/* EDIT: Institution */}
                    {RESEARCHER.institution}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {/* EDIT: Location */}
                    {RESEARCHER.location}
                  </span>
                </div>

                <div className="space-y-4 mb-8">
                  <p className="text-slate-500 leading-relaxed">
                    {/* EDIT: Main bio paragraph */}
                    {RESEARCHER.bio}
                  </p>
                  {RESEARCHER.bioExtended && (
                    <p className="text-slate-500 leading-relaxed">
                      {/* EDIT: Extended bio paragraph */}
                      {RESEARCHER.bioExtended}
                    </p>
                  )}
                </div>

                {/* Social & Contact Links */}
                <div className="flex flex-wrap gap-3">
                  {RESEARCHER.email && (
                    <a
                      href={`mailto:${RESEARCHER.email}`}
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-forest-600 hover:bg-forest-700 text-white text-sm font-semibold rounded-xl transition-all duration-300 shadow-md shadow-forest-600/25 hover:-translate-y-0.5"
                    >
                      <Mail className="w-4 h-4" />
                      Email
                    </a>
                  )}
                  {RESEARCHER.github && (
                    <a
                      href={RESEARCHER.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white text-sm font-semibold rounded-xl transition-all duration-300 shadow-md shadow-slate-800/25 hover:-translate-y-0.5"
                    >
                      <Github className="w-4 h-4" />
                      GitHub
                    </a>
                  )}
                  {RESEARCHER.linkedin && (
                    <a
                      href={RESEARCHER.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl transition-all duration-300 shadow-md shadow-blue-600/25 hover:-translate-y-0.5"
                    >
                      <Linkedin className="w-4 h-4" />
                      LinkedIn
                    </a>
                  )}
                  {RESEARCHER.website && (
                    <a
                      href={RESEARCHER.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-water-600 hover:bg-water-700 text-white text-sm font-semibold rounded-xl transition-all duration-300 shadow-md shadow-water-600/25 hover:-translate-y-0.5"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Website
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
