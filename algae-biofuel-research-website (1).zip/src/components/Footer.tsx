import { Droplets, ArrowUp } from 'lucide-react';

/* =============================================
   FOOTER COMPONENT
   ── Edit the links, copyright text, and
      any additional info below
   ============================================= */

export default function Footer() {
  return (
    <footer className="relative bg-slate-900 text-white overflow-hidden">
      {/* Top gradient line */}
      <div className="h-1 bg-gradient-to-r from-forest-500 via-water-500 to-forest-500" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand Column */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 rounded-xl bg-forest-600">
                <Droplets className="w-5 h-5 text-white" />
              </div>
              <span className="font-serif font-bold text-lg">From Pond to Pump</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
              {/* EDIT: Footer description */}
              An open-source environmental research initiative transforming eutrophic microalgae
              into sustainable, zero-waste biofuel.
            </p>
            <p className="text-slate-500 text-xs">
              {/* EDIT: License/open-source note */}
              All research data and publications are released under open-access principles.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-sm tracking-wider uppercase text-slate-400 mb-4">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {/* EDIT: Update or add footer links */}
              {[
                { label: 'About the Research', href: '#about' },
                { label: 'Methodology', href: '#methodology' },
                { label: 'Open Journal', href: '#journal' },
                { label: 'Photo Gallery', href: '#gallery' },
                { label: 'The Researcher', href: '#researcher' },
              ].map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-slate-400 hover:text-forest-400 text-sm transition-colors duration-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact / CTA */}
          <div>
            <h4 className="font-semibold text-sm tracking-wider uppercase text-slate-400 mb-4">
              Get Involved
            </h4>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
              {/* EDIT: CTA text */}
              Interested in collaborating, replicating this research, or supporting
              the project? Reach out directly.
            </p>
            <a
              href="#researcher"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-forest-600 hover:bg-forest-700 text-white text-sm font-semibold rounded-xl transition-all duration-300"
            >
              Contact Researcher
            </a>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-slate-500 text-sm">
            {/* EDIT: Copyright notice */}
            &copy; {new Date().getFullYear()} From Pond to Pump. Open-source research project.
          </p>
          <a
            href="#hero"
            className="inline-flex items-center gap-2 text-slate-500 hover:text-forest-400 text-sm transition-colors"
          >
            Back to top <ArrowUp className="w-4 h-4" />
          </a>
        </div>
      </div>
    </footer>
  );
}
