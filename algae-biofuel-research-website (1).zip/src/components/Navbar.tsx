import { useState, useEffect } from 'react';
import { Menu, X, Droplets } from 'lucide-react';

/* =============================================
   NAVBAR COMPONENT
   - Edit navigation links below
   - Each link scrolls to its section by ID
   ============================================= */

const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Methodology', href: '#methodology' },
  { label: 'Journal', href: '#journal' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'Researcher', href: '#researcher' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-md shadow-lg shadow-forest-900/5'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* ── LOGO / SITE TITLE ── */}
          <a href="#hero" className="flex items-center gap-2 group">
            <div className={`p-2 rounded-xl transition-colors duration-300 ${
              scrolled ? 'bg-forest-600' : 'bg-white/20 backdrop-blur-sm'
            }`}>
              <Droplets className="w-5 h-5 text-white" />
            </div>
            <span className={`font-serif font-bold text-lg tracking-tight transition-colors duration-300 ${
              scrolled ? 'text-forest-900' : 'text-white'
            }`}>
              From Pond to Pump
            </span>
          </a>

          {/* ── DESKTOP NAV LINKS ── */}
          <div className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                  scrolled
                    ? 'text-slate-600 hover:text-forest-700 hover:bg-forest-50'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                {link.label}
              </a>
            ))}
            <a
              href="#journal"
              className={`ml-3 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 ${
                scrolled
                  ? 'bg-forest-600 text-white hover:bg-forest-700 shadow-md shadow-forest-600/25'
                  : 'bg-white text-forest-800 hover:bg-forest-50 shadow-lg shadow-black/10'
              }`}
            >
              Read the Journal
            </a>
          </div>

          {/* ── MOBILE MENU BUTTON ── */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className={`md:hidden p-2 rounded-lg transition-colors ${
              scrolled ? 'text-slate-700 hover:bg-slate-100' : 'text-white hover:bg-white/10'
            }`}
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* ── MOBILE MENU ── */}
      <div
        className={`md:hidden overflow-hidden transition-all duration-300 bg-white/95 backdrop-blur-md ${
          mobileOpen ? 'max-h-96 border-t border-slate-100' : 'max-h-0'
        }`}
      >
        <div className="px-4 py-3 space-y-1">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              className="block px-4 py-3 rounded-lg text-slate-700 hover:bg-forest-50 hover:text-forest-700 font-medium transition-colors"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#journal"
            onClick={() => setMobileOpen(false)}
            className="block mt-2 px-4 py-3 bg-forest-600 text-white text-center rounded-lg font-semibold hover:bg-forest-700 transition-colors"
          >
            Read the Journal
          </a>
        </div>
      </div>
    </nav>
  );
}
