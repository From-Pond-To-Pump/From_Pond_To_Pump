import { Waves, Fuel, Recycle, TrendingDown } from 'lucide-react';

/* =============================================
   ABOUT THE RESEARCH SECTION
   ── Edit the descriptive text, mission points,
      and statistics in the arrays below
   ============================================= */

/* EDIT: Update these mission pillars */
const MISSION_PILLARS = [
  {
    icon: Waves,
    title: 'Combating Eutrophication',
    description:
      'Excess nitrogen and phosphorus from agricultural runoff cause harmful algal blooms in local water bodies. Our project directly addresses this ecological crisis by harvesting the very organisms that thrive in these polluted waters.',
    color: 'water' as const,
  },
  {
    icon: Fuel,
    title: 'Sustainable Biofuel Production',
    description:
      'Nitrogen-stressed microalgae accumulate lipids at significantly higher rates, making them ideal feedstock for low-cost biodiesel. We convert an environmental problem into a renewable energy source.',
    color: 'forest' as const,
  },
  {
    icon: Recycle,
    title: 'Zero-Waste Philosophy',
    description:
      'Every byproduct of our process is repurposed — from spent biomass as organic fertilizer to glycerol as an industrial feedstock. Nothing goes to landfill; everything returns to the cycle.',
    color: 'water' as const,
  },
  {
    icon: TrendingDown,
    title: 'Low-Cost & Scalable',
    description:
      'By sourcing algae directly from eutrophic ponds, we eliminate the need for expensive cultivation systems. Our prototype is designed for replication in rural and resource-limited communities.',
    color: 'forest' as const,
  },
];

const colorMap = {
  water: {
    bg: 'bg-water-50',
    iconBg: 'bg-water-100',
    iconColor: 'text-water-600',
    border: 'border-water-100',
    hoverBorder: 'hover:border-water-300',
  },
  forest: {
    bg: 'bg-forest-50',
    iconBg: 'bg-forest-100',
    iconColor: 'text-forest-600',
    border: 'border-forest-100',
    hoverBorder: 'hover:border-forest-300',
  },
};

export default function About() {
  return (
    <section id="about" className="relative py-24 lg:py-32 bg-white overflow-hidden">
      {/* Subtle background decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-forest-50 rounded-full blur-3xl opacity-50 -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-water-50 rounded-full blur-3xl opacity-50 translate-y-1/2 -translate-x-1/2" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 lg:mb-20">
          <span className="reveal inline-block px-4 py-1.5 bg-forest-50 text-forest-700 text-sm font-semibold rounded-full border border-forest-100 mb-6">
            {/* EDIT: Section label */}
            Our Mission
          </span>
          <h2 className="reveal reveal-delay-1 font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 leading-tight mb-6">
            {/* EDIT: Section heading */}
            A Dual Mission for{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-forest-600 to-water-600">
              Ecological Restoration
            </span>
          </h2>
          <p className="reveal reveal-delay-2 text-lg text-slate-500 leading-relaxed">
            {/* EDIT: Section description */}
            Our research sits at the intersection of environmental remediation and renewable energy.
            We transform polluted aquatic ecosystems into sources of clean, sustainable biofuel
            through an innovative, zero-waste approach.
          </p>
        </div>

        {/* Mission Pillars Grid */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {MISSION_PILLARS.map((pillar, i) => {
            const colors = colorMap[pillar.color];
            const Icon = pillar.icon;
            return (
              <div
                key={i}
                className={`reveal reveal-delay-${i + 1} group relative bg-white rounded-2xl p-8 border-2 ${colors.border} ${colors.hoverBorder} transition-all duration-500 hover:shadow-xl hover:shadow-slate-900/5 hover:-translate-y-1`}
              >
                <div className={`inline-flex p-3 rounded-xl ${colors.iconBg} mb-5`}>
                  <Icon className={`w-6 h-6 ${colors.iconColor}`} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">
                  {/* EDIT: Pillar title */}
                  {pillar.title}
                </h3>
                <p className="text-slate-500 leading-relaxed">
                  {/* EDIT: Pillar description */}
                  {pillar.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Bottom highlight bar */}
        <div className="reveal mt-16 lg:mt-20 bg-gradient-to-r from-forest-600 to-water-600 rounded-2xl p-8 lg:p-12 text-white">
          <div className="grid sm:grid-cols-3 gap-8 text-center">
            {/* EDIT: Update these key statistics */}
            {[
              {
                value: 'Eutrophication',
                label: 'Directly targets nutrient pollution in local water bodies',
              },
              {
                value: 'Microalgae',
                label: 'Lipid-rich biomass from nitrogen-stressed cultures',
              },
              {
                value: 'Biofuel',
                label: 'Scalable, low-cost biodiesel from algal lipids',
              },
            ].map((item, i) => (
              <div key={i}>
                <div className="text-xl lg:text-2xl font-bold mb-2">{item.value}</div>
                <p className="text-white/70 text-sm leading-relaxed">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
